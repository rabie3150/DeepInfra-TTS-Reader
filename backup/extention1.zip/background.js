// Create the context menu when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "readAloud",
    title: "Read aloud with DeepInfra TTS",
    contexts: ["selection"]
  });
});

// Listen for context menu clicks and process the selected text
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "readAloud" && info.selectionText) {
    processText(info.selectionText, tab);
  }
});

// Main function: check cache, fetch TTS if needed, and send audio to the content script
async function processText(text, tab) {
  try {
    let audioData = await getCachedAudio(text);
    if (!audioData) {
      audioData = await fetchTTS(text);
      await cacheAudio(text, audioData);
    }
    if (tab && tab.id) {
      // Attempt to ping the content script first.
      chrome.tabs.sendMessage(tab.id, { action: "ping" }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("Content script not found, injecting it...", chrome.runtime.lastError.message);
          // If the content script is not present, inject it using chrome.scripting.
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content.js"]
          }, () => {
            if (chrome.runtime.lastError) {
              console.error("Injection failed:", chrome.runtime.lastError.message);
            } else {
              // Now send the playAudio message after injection.
              chrome.tabs.sendMessage(tab.id, { action: "playAudio", audioUrl: audioData });
            }
          });
        } else {
          // Content script is present; send the playAudio message.
          chrome.tabs.sendMessage(tab.id, { action: "playAudio", audioUrl: audioData });
        }
      });
    }
  } catch (e) {
    console.error("Error in processText:", e);
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { action: "ttsError", message: e.message });
    }
  }
}

// Function to call DeepInfra's TTS endpoint using the free API (no API key)
async function fetchTTS(text) {
  const apiUrl = "https://api.deepinfra.com/v1/inference/hexgrad/Kokoro-82M?version=2f0893cb40f2ae8356e8e1f7463e52236425f5fd";
  const payload = {
    text: text,
    output_format: "wav" // Example response uses WAV format
  };

  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Accept": "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9,fr;q=0.8,fr-FR;q=0.7,ar;q=0.6",
      "Content-Type": "application/json",
      "Cache-Control": "no-cache",
      "Pragma": "no-cache",
      // Mimic a request from deepinfra.com:
      "Origin": "https://deepinfra.com",
      "Referer": "https://deepinfra.com/"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error("TTS request failed with status " + response.status);
  }
  const data = await response.json();
  const audio = data.audio;
  if (!audio) {
    throw new Error("No audio data returned from TTS API.");
  }
  return audio;
}

// Simple caching functions using chrome.storage.local
function getCachedAudio(text) {
  return new Promise(resolve => {
    chrome.storage.local.get([text], result => {
      resolve(result[text]);
    });
  });
}

function cacheAudio(text, audioData) {
  return new Promise(resolve => {
    chrome.storage.local.set({ [text]: audioData }, () => {
      resolve();
    });
  });
}
