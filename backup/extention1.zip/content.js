chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    sendResponse({ status: "ok" });
  } else if (request.action === "playAudio") {
    playAudio(request.audioUrl);
  } else if (request.action === "ttsError") {
    alert("TTS Error: " + request.message);
  }
});

// Use the Web Audio API to decode and play audio from a data URL.
async function playAudio(dataUrl) {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioCtx = new AudioContext();
    // Fetch the audio data from the data URL.
    const response = await fetch(dataUrl);
    const arrayBuffer = await response.arrayBuffer();
    // Decode the audio data.
    audioCtx.decodeAudioData(arrayBuffer, (audioBuffer) => {
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);
      source.start(0);
      console.log("Playback started.");
    }, (error) => {
      console.error("Error decoding audio data:", error);
    });
  } catch (error) {
    console.error("Error playing audio:", error);
  }
}
