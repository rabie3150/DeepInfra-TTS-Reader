// content.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    sendResponse({ status: "ok" });
  } else if (request.action === "playAudio") {
    playAudio(request.audioUrl, request.text);
  } else if (request.action === "ttsError") {
    alert("TTS Error: " + request.message);
  }
});

// Function to highlight a sentence in the document by wrapping its first occurrence in a span.
function highlightSentence(sentence) {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
  let node;
  while (node = walker.nextNode()) {
    const index = node.textContent.indexOf(sentence);
    if (index !== -1) {
      const span = document.createElement("span");
      span.className = "tts-highlight";
      span.style.backgroundColor = "#ff9800"; // highlight color
      span.style.color = "#121212"; // text color for contrast
      
      const before = document.createTextNode(node.textContent.slice(0, index));
      const match = document.createTextNode(sentence);
      const after = document.createTextNode(node.textContent.slice(index + sentence.length));
      
      span.appendChild(match);
      const parent = node.parentNode;
      parent.insertBefore(before, node);
      parent.insertBefore(span, node);
      parent.insertBefore(after, node);
      parent.removeChild(node);
      
      break; // Only highlight the first occurrence
    }
  }
}

// Remove any existing highlight added by our extension.
function removeHighlight() {
  const highlights = document.querySelectorAll("span.tts-highlight");
  highlights.forEach(span => {
    const parent = span.parentNode;
    parent.replaceChild(document.createTextNode(span.textContent), span);
  });
}

// Decode and play audio from a data URL, and synchronize sentence highlighting.
async function playAudio(dataUrl, text) {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioCtx = new AudioContext();
    const response = await fetch(dataUrl);
    const arrayBuffer = await response.arrayBuffer();
    const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
    
    const source = audioCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioCtx.destination);
    
    const totalDuration = audioBuffer.duration;
    
    // Split text into sentences using regex.
    const sentences = text.match(/[^\.!\?]+[\.!\?]+/g) || [text];
    const totalWords = text.split(/\s+/).length;
    let sentenceTimings = [];
    let currentTime = 0;
    sentences.forEach(sentence => {
      const wordCount = sentence.split(/\s+/).length;
      const duration = (wordCount / totalWords) * totalDuration;
      sentenceTimings.push({ start: currentTime, end: currentTime + duration, sentence: sentence.trim() });
      currentTime += duration;
    });
    
    const startTime = audioCtx.currentTime;
    source.start(0);
    
    let currentHighlightedIndex = -1;
    const highlightInterval = setInterval(() => {
      const elapsed = audioCtx.currentTime - startTime;
      let sentenceIndex = sentenceTimings.findIndex(t => elapsed >= t.start && elapsed < t.end);
      
      if (sentenceIndex !== currentHighlightedIndex) {
        removeHighlight();
        if (sentenceIndex !== -1) {
          highlightSentence(sentenceTimings[sentenceIndex].sentence);
          currentHighlightedIndex = sentenceIndex;
        }
      }
      
      if (elapsed >= totalDuration) {
        clearInterval(highlightInterval);
        removeHighlight();
      }
    }, 100);
    
  } catch (error) {
    console.error("Error playing audio:", error);
  }
}
