// background.js

// Create the context menu when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "readAloud",
    title: "Read aloud with DeepInfra TTS",
    contexts: ["selection"]
  });
});

// Listen for context menu clicks and process the selected text
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "readAloud" && info.selectionText) {
    processText(info.selectionText, tab);
  }
});

// Main function: check cache, fetch TTS if needed, and send audio (with settings) to the content script
async function processText(text, tab) {
  try {
    let audioData = await getCachedAudio(text);
    if (!audioData) {
      audioData = await fetchTTS(text);
      await cacheAudio(text, audioData);
    }
    if (tab && tab.id) {
      // Ping content script; if not present, inject it.
      chrome.tabs.sendMessage(tab.id, { action: "ping" }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("Content script not found, injecting it...", chrome.runtime.lastError.message);
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content.js"]
          }, () => {
            if (chrome.runtime.lastError) {
              console.error("Injection failed:", chrome.runtime.lastError.message);
            } else {
              chrome.tabs.sendMessage(tab.id, { action: "playAudio", audioUrl: audioData, text: text });
            }
          });
        } else {
          chrome.tabs.sendMessage(tab.id, { action: "playAudio", audioUrl: audioData, text: text });
        }
      });
    }
  } catch (e) {
    console.error("Error in processText:", e);
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { action: "ttsError", message: e.message });
    }
  }
}

// Function to call DeepInfra's TTS endpoint using the free API (no API key)
// Reads the preset_voice and speed from chrome.storage.sync.
async function fetchTTS(text) {
  const settings = await new Promise(resolve => {
    chrome.storage.sync.get(["preset_voice", "speed"], resolve);
  });
  const preset_voice = settings.preset_voice || "am_liam"; // default voice if none selected
  const speed = settings.speed || 1.0; // default speed

  const apiUrl = "https://api.deepinfra.com/v1/inference/hexgrad/Kokoro-82M?version=2f0893cb40f2ae8356e8e1f7463e52236425f5fd";
  const payload = {
    text: text,
    output_format: "wav", // Using WAV format in this example
    preset_voice: preset_voice,
    speed: speed
  };

  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Accept": "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9,fr;q=0.8,fr-FR;q=0.7,ar;q=0.6",
      "Content-Type": "application/json",
      "Cache-Control": "no-cache",
      "Pragma": "no-cache",
      "Origin": "https://deepinfra.com",
      "Referer": "https://deepinfra.com/"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error("TTS request failed with status " + response.status);
  }
  const data = await response.json();
  const audio = data.audio;
  if (!audio) {
    throw new Error("No audio data returned from TTS API.");
  }
  return audio;
}

// Simple caching functions using chrome.storage.local
function getCachedAudio(text) {
  return new Promise(resolve => {
    chrome.storage.local.get([text], result => {
      resolve(result[text]);
    });
  });
}

function cacheAudio(text, audioData) {
  return new Promise(resolve => {
    chrome.storage.local.set({ [text]: audioData }, () => {
      resolve();
    });
  });
}
