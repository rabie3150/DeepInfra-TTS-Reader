// popup.js

let voiceDescriptions = [];

// Load voices from voices.json.
function loadVoices() {
  fetch(chrome.runtime.getURL('voices.json'))
    .then(response => response.json())
    .then(data => {
      voiceDescriptions = data;
      initLanguageSelector();
      updateVoiceSelector();
      loadSettings();
    })
    .catch(error => {
      console.error("Error loading voices.json", error);
    });
}

// Populate language selector with unique languages from voiceDescriptions.
function initLanguageSelector() {
  const languageSelector = document.getElementById("language-selector");
  const languages = new Set();
  voiceDescriptions.forEach(voice => {
    languages.add(voice.language);
  });
  const languageArray = Array.from(languages).sort();
  languageArray.forEach(lang => {
    const option = document.createElement("option");
    option.value = lang;
    option.textContent = lang;
    languageSelector.appendChild(option);
  });
}

// Update voice selector options based on selected language.
function updateVoiceSelector() {
  const languageSelector = document.getElementById("language-selector");
  const voiceSelector = document.getElementById("voice-selector");
  const selectedLanguage = languageSelector.value;
  voiceSelector.innerHTML = "";
  voiceDescriptions
    .filter(voice => voice.language === selectedLanguage)
    .forEach(voice => {
      const option = document.createElement("option");
      option.value = voice.code;
      option.textContent = voice.title;
      voiceSelector.appendChild(option);
    });
}

// Load saved settings from chrome.storage.sync.
function loadSettings() {
  chrome.storage.sync.get(["preset_voice", "speed"], (settings) => {
    const speedInput = document.getElementById("speed-input");
    const speedValue = document.getElementById("speed-value");
    if (settings.speed) {
      speedInput.value = settings.speed;
      speedValue.textContent = settings.speed;
    }
    if (settings.preset_voice) {
      // Find the voice in voiceDescriptions.
      const voice = voiceDescriptions.find(v => v.code === settings.preset_voice);
      if (voice) {
        document.getElementById("language-selector").value = voice.language;
        updateVoiceSelector();
        document.getElementById("voice-selector").value = settings.preset_voice;
      }
    } else {
      updateVoiceSelector();
    }
  });
}

// Save settings to chrome.storage.sync.
function saveSettings() {
  const preset_voice = document.getElementById("voice-selector").value;
  const speed = parseFloat(document.getElementById("speed-input").value);
  chrome.storage.sync.set({ preset_voice, speed }, () => {
    alert("Settings saved!");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadVoices();
  
  document.getElementById("language-selector").addEventListener("change", updateVoiceSelector);
  
  const speedInput = document.getElementById("speed-input");
  const speedValue = document.getElementById("speed-value");
  speedInput.addEventListener("input", () => {
    speedValue.textContent = speedInput.value;
  });
  
  document.getElementById("save-btn").addEventListener("click", saveSettings);
});
